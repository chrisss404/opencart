<?php
// Text
$_['text_success'] = 'Success: API session successfully started!';

// Error
$_['error_login']  = 'Warning: No match for Username and/or Password.';